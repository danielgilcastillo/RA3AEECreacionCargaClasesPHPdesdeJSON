<?php

include_once('clases.php');

// CONSTRUIMOS UN OBJETO TIENDA Y TODO SU CONTENIDO (CATEGORIAS, PRODUCTOS Y VARIANTES)

// Crear la tienda
$tienda = new Tienda();

// Crear categorías ELECTRONICA
$electronica = new Categoria("Electronica");

// Crear productos para la categoría Electrónica
$iphone = new Producto("iPhone 13", "Apple", 999);
$galaxy = new Producto("Galaxy S21", "Samsung", 799);

// Crear variantes
$variante1 = new Variante("Negro", "128GB", 999);
$variante2 = new Variante("Blanco", "64GB", 229);
$variante3 = new Variante("Azul", "128GB", 999);
$variante4 = new Variante("Rosa", "64GB", 229);


$iphone->agregarVariante($variante1);
$iphone->agregarVariante($variante2);
$galaxy->agregarVariante($variante3);
$galaxy->agregarVariante($variante4);

$electronica->agregarProducto($iphone);
$electronica->agregarProducto($galaxy);

$tienda->agregarCategoria($electronica);


// Crear categorías HOGAR
$hogar = new Categoria("Hogar");

// Crear productos para la categoría Electrónica
$rumba = new Producto("Rumba", "Samsung", 999);
$lavadora = new Producto("Lavadora", "LG", 799);

// Crear variantes
$variante1 = new Variante("Negro", "12m2", 999);
$variante2 = new Variante("Blanco", "14m2", 229);
$variante3 = new Variante("Azul", "4kg", 999);
$variante4 = new Variante("Rosa", "8kg", 229);

$rumba->agregarVariante($variante1);
$rumba->agregarVariante($variante2);
$lavadora->agregarVariante($variante3);
$lavadora->agregarVariante($variante4);

$hogar->agregarProducto($rumba);
$hogar->agregarProducto($lavadora);

$tienda->agregarCategoria($hogar);

// YA TENEMOS LA TIENDA CONSTRUIDA 


// CREAR UN FICHERO JSON A PARTIR DEL OBJETO TIENDA
$tiendaComoUnStringenjson = json_encode($tienda);
echo $tiendaComoUnStringenjson;
file_put_contents("tienda.json", $tiendaComoUnStringenjson);


// LEER NUEVAMENTE EL FICHERO JSON Y METERLO EN UN NUEVO OBJETO TIENDA
echo "<br>LEEMOS EL JSON Y LO METEMOS EN OBJETO TIENDA<br>";
$ficheroJSONleido = file_get_contents("tienda.json");
$nuevatienda = json_decode($ficheroJSONleido);
print_r($nuevatienda->categorias[0]->productos[0]->variantes[0]->color);
